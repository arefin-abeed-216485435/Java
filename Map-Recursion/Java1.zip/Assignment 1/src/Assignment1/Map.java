

package Assignment1;
import java.util.*;


public class Map {
	boolean [][] map; 
	private int row;
	private int column;
	/**
	 * This is the constructor that constructs the city map, 
	 * which is a grid of row by column.
	 * @param row is the number of east-west streets of the city
	 * @param column is the number of north-south streets of the city
	 */
	public Map(int row, int column) {
		
		this.row= row - 1;
		this.column= column - 1;
	}
	/**
	 * This method checks the correctness of the input parameters. If the preconditions are not met 
	 * an exception is thrown, otherwise depending to the direction, it calls 
	 * one of the four recursive functions of goSouthWest, goSouthEast, goNorthWest and goNorthEast.
	 * @param startRow is the starting row of the path 
	 * @param startCol is the starting column of the path
	 * @param destRow is the destination row
	 * @param destCol is the destination column
	 * @param path is the path that is constructed while the recursive method is called. In first round,  it will be "".
	 * @return returns a string representing the path to the destination. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 * @pre the integer parameters should be in the range of the city grid.(i.e. [0, N) if N is the number of east-west streets and [0, M) if 
	 * M is the number of north-south streets.) 
	 * @exception IllegalArgumentException if any of the precondition did not meet.
	 */
	public String getPath (int startRow, int startCol, int destRow, int destCol , String path) {
		 
		String result = "";
		/*
		 * The precondition is that the starting and destination row and column is greater than 0 
		 * and less than the total number of row - 1 and column - 1 respectively (as we are calculating from 0).
		 * This if conditions only run the code if it meets the preconditions or throws an exception.
		 */
		if ((startRow >= 0 && startCol >= 0 && destRow >= 0 && destCol >= 0) && 
			(startRow <= this.row && startCol <= this.column && destRow <= this.row && destCol <= this.column) ) {
			
			if ((destRow <= startRow) && (destCol <= startCol)){
				
				result = goSouthWest(startRow, startCol,destRow,destCol, path);
				
			} else if ((destRow <= startRow) && (destCol >= startCol)){
				
				result = goSouthEast(startRow, startCol,destRow,destCol, path);
				
			} else if ((destRow >= startRow) && (destCol >= startCol)){
				
				result = goNorthEast(startRow, startCol,destRow,destCol, path);
				
			} else if ((destRow >= startRow) && (destCol <= startCol)){
				
				result = goNorthWest(startRow, startCol,destRow,destCol, path);
			} 
		} else {
			
			throw new IllegalArgumentException();
		}
		
		return result;
		 
	}
	/**
	 * This method returns a path from the source (startRow, startCol) to the destination (destRow, destCol).
	 * Please note that the returning path does not include the starting point.  
	 * @param startRow is the starting row of the path 
	 * @param startCol is the starting column of the path
	 * @param destRow is the destination row
	 * @param destCol is the destination column
	 * @param path is the path that is constructed while the recursive method is called. In first round,  it will be "".
	 * @return returns a string representing the path to the destination. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 * @pre <code> startRow >= destRow </code> and <code> startCol >= destCol </code>
	 */
	
	private String goSouthWest (int startRow, int startCol, int destRow, int destCol , String path) {
		
		String result = "";
		
		// This if condition checks the precondition for this method and give the expected result or path.
		
		if (startRow > destRow) {
			
			result = "(" + (startRow - 1) + "," + (startCol) + ") " + goSouthWest((startRow - 1), startCol,destRow,destCol,"");
			
		} else if (startCol > destCol) {
			
			result = "(" + (startRow) + "," + (startCol - 1) + ") " + goSouthWest(startRow, (startCol - 1),destRow,destCol, "");
		} 	
		
		return result;
	}
	
	/**
	 * This method returns a path from the source (startRow, startCol) to the destination (destRow, destCol).
	 * Please note that the returning path does not include the starting point. 
	 * @param startRow is the starting row of the path 
	 * @param startCol is the starting column of the path
	 * @param destRow is the destination row
	 * @param destCol is the destination column
	 * @param path is the path that is constructed while the recursive method is called. In first round,  it will be "".
	 * @return returns a string representing the path to the destination. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 * @pre <code> startRow >= destRow </code> and <code> startCol <= destCol </code>
	 */
	private String goSouthEast (int startRow, int startCol, int destRow, int destCol , String path) {
		
		String result = "";
		
		// This if condition checks the precondition for this method and give the expected result or path.
		
		if (startRow > destRow) {
			
			result = "(" + (startRow - 1) + "," + (startCol) + ") " + goSouthEast((startRow - 1), startCol,destRow,destCol,"");
			
		} else if (startCol < destCol) {
			
			result = "(" + (startRow) + "," + (startCol + 1) + ") " + goSouthEast(startRow, (startCol + 1),destRow,destCol, "");
		} 
		
		return result;
	}
	
	/**
	 * This method returns a path from the source (startRow, startCol) to the destination (destRow, destCol).
	 * Please note that the returning path does not include the starting point. 
	 * @param startRow is the starting row of the path 
	 * @param startCol is the starting column of the path
	 * @param destRow is the destination row
	 * @param destCol is the destination column
	 * @param path is the path that is constructed while the recursive method is called. In first round,  it will be "".
	 * @return returns a string representing the path to the destination. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 * @pre <code> startRow <= destRow </code> and <code> startCol >= destCol </code>
	 */
	private String goNorthEast (int startRow, int startCol, int destRow, int destCol , String path) {
		
		String result = "";
		
		// This if condition checks the precondition for this method and give the expected result or path.
		
		if (startRow < destRow) {
			
			result = "(" + (startRow + 1) + "," + (startCol) + ") " + goNorthEast((startRow + 1), startCol,destRow,destCol,"");
			
		} else if (startCol < destCol) {
			
			result = "(" + (startRow) + "," + (startCol + 1) + ") " + goNorthEast(startRow, (startCol + 1),destRow,destCol, "");
		} 
		
		return result;
	}

	/**
	 * This method returns a path from the source (startRow, startCol) to the destination (destRow, destCol).
	 * Please note that the returning path does not include the starting point. 
	 * @param startRow is the starting row of the path 
	 * @param startCol is the starting column of the path
	 * @param destRow is the destination row
	 * @param destCol is the destination column
	 * @param path is the path that is constructed while the recursive method is called. In first round,  it will be "".
	 * @return returns a string representing the path to the destination. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 * @pre <code> startRow >= destRow </code> and <code> startCol <= destCol </code>
	 */
	private String goNorthWest (int startRow, int startCol, int destRow, int destCol , String path) {
		
		String result = "";
		
		// This if condition checks the precondition for this method and give the expected result or path.
		
		if (startRow < destRow) {
			
			result = "(" + (startRow + 1) + "," + (startCol) + ") " + goNorthWest((startRow + 1), startCol,destRow,destCol,"");
			
		} else if (startCol > destCol) {
			
			result = "(" + (startRow) + "," + (startCol - 1) + ") " + goNorthWest(startRow, (startCol - 1),destRow,destCol, "");
		} 
		
		return result;
	}
	
	/**
	 * This method find a path from (startRow, startCol) to a border point of the city. 
	 * Please note that the starting point should be included in the path.
	 * @param startRow is the starting row of the path
	 * @param startCol is the starting column of the path
	 * @return is a path from (starting row, staring col) to a border point of the city. The format of the output is (x1,y1) (x2,y2) (x3,y3)...
	 */
	
	private ArrayList<String> point = new ArrayList<String>(); //ArrayList created to store all the points and check for any repeat of same point. 
	
	public String findPath (int startRow, int startCol) {
		
		String result = "";

		// Another private helper method,helperfindPath, is used to get the solution. Both main and helper methods are recurring.
		 
		result = helperfindPath(startRow, startCol);
		
		boolean isCont = true; // This is used to check for any repetition.
		
		// A nested for loop is used to check all the points of the path for any repetition.
		
		for(int i = 0; i < point.size(); i++) {
			
			for(int j = i + 1; j < point.size(); j++) {
				
				isCont = isCont && (!point.get(i).equals((point.get(j))));
			}
		}
		
		// If any point is repeated, the code runs again until there is no repetition.
		
		if(isCont == false) {
			
			point.clear();

		    result = findPath(startRow,startCol);
		}
		
		return result;
	}
	
	private String helperfindPath(int startRow, int startCol) {
		
		String result ="";
		
		Random ranDir = new Random(); // This will be used to generate random direction.
		
		// This if condition checks if the preconditions are met or not.

		if (startRow <= this.row && startCol <= this.column && startRow >= 0 && startCol >= 0) {
			
			int plusminus;
			
			// This if condition is used to generate random plus or minus sign which will be used to generate random direction.
			
			if(ranDir.nextBoolean()) {
				
				plusminus = 1;
				
			} else {
				
				plusminus = -1;
			}
			
			// This if condition is used to generate random path to get out of the city.
			
			if(ranDir.nextBoolean()) {
				
				point.add("(" + startRow + "," + startCol + ") ");
				
				result = "(" + startRow + "," + startCol + ") " + helperfindPath(startRow + plusminus, startCol);
				
			} else {
				
				point.add("(" + startRow + "," + startCol + ") ");
				
				result = "(" + startRow + "," + startCol + ") " + helperfindPath(startRow, startCol + plusminus);
			}
		}
		
		return result;
		
	}
	

		
} // end of class
