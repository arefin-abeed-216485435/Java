package Assignment2;

import java.util.ArrayList;
import java.util.Scanner;
import java.text.DecimalFormat;

import java.io.*;



/**
* This class generates a transcript for each student, whose information is in the text file.
* 
*
*/
public class Transcript {
	private ArrayList<Object> grade = new ArrayList<Object>();
	private File inputFile;
	private String outputFile;
	static Scanner input = new Scanner(System.in);

	/**
	 * This the the constructor for Transcript class that 
	 * initializes its instance variables and call readFie private
	 * method to read the file and construct this.grade.
	 * @param inFile is the name of the input file.
	 * @param outFile is the name of the output file.
	 */
	public Transcript(String inFile, String outFile) {
		inputFile = new File(inFile);	
		outputFile = outFile;	
		grade = new ArrayList<Object>();
		this.readFile();
	}// end of Transcript constructor

	/** 
	 * This method reads a text file and add each line as 
	 * an entry of grade ArrayList.
	 * @exception It throws FileNotFoundException if the file is not found.
	 */
	private void readFile() {
		Scanner sc = null; 
		try {
			sc = new Scanner(inputFile);	
			while(sc.hasNextLine()){
				grade.add(sc.nextLine());
	        }      
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			sc.close();
		}		
	} // end of readFile
	
/**
 * This method creates and returns an ArrayList, whose element is
 * an object of class Student. The object at each element is created by aggregating ALL the
 * information, that is found for one student in the grade ArrayList of class Transcript.
 * @return the array list of students with all the necessary information.
 */
public ArrayList<Student> buildStudentArray() {
	
	ArrayList<Student> students = new ArrayList<Student>();
    
	for(int j = 0; j < this.copyGradesToString().size(); j++) {
		
		ArrayList<Assessment> assessments = new ArrayList<Assessment>();
		ArrayList<Double> grades = new ArrayList<Double>();
		ArrayList<Integer> weights = new ArrayList<Integer>();
		    
		String[] inf = this.copyGradesToString().get(j).split(",");
        int studentnumber = -1;
        
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentID().equals(inf[2])) {
               studentnumber = i;
               }
        }
            
        if (studentnumber > -1) {
           Course course = null;
    	   Student student = null;
           student = students.get(studentnumber);
                    
           for (int i = 3; i < inf.length - 1; i++) {
                    	
               int indexOfBracket1 = inf[i].indexOf('(');
               int indexOfBracket2 = inf[i].indexOf(')');
               int weight = Integer.parseInt(inf[i].substring(1, indexOfBracket1));
               weights.add(weight);
               Assessment assadder = Assessment.getInstance(inf[i].charAt(0), weight);
               assessments.add(assadder);
               double grade = Double.parseDouble(inf[i].substring(indexOfBracket1 + 1, indexOfBracket2));
               grades.add(grade / 100);
               }
                    
               double credit = Double.parseDouble(inf[1]);
               course = new Course(inf[0], assessments, credit);
               student.addCourse(course);
               student.addGrade(grades, weights);
            } else {
               Course course = null;
         	   Student student = null;
               for (int i = 3; i < inf.length - 1; i++) {
                    	
                    int indexOfBracket1 = inf[i].indexOf('(');
                    int indexOfBracket2 = inf[i].indexOf(')');
                	int weight = Integer.parseInt(inf[i].substring(1, indexOfBracket1));
                    weights.add(weight);
                    Assessment assadder = Assessment.getInstance(inf[i].charAt(0), weight);
                    assessments.add(assadder);
                    double grade = Double.parseDouble(inf[i].substring(indexOfBracket1 + 1, indexOfBracket2));
                    grades.add(grade / 100);
                    }
                    double credit = Double.parseDouble(inf[1]);
                    course = new Course(inf[0], assessments, credit);
                    student = new Student(inf[2], inf[inf.length - 1], null);
                    student.addCourse(course);
                    student.addGrade(grades, weights);
                    students.add(student);
            }

    }
    return students;
}// end of buildStudentArray

/**
 * This is a private helper method which copies the information from grades attribute and store them in a String array list.
 * @return the String array list containing the information of students we want transcripts of.
 */
private ArrayList<String> copyGradesToString() {
	ArrayList<String> copyGrades = new ArrayList<String>();
	for(int i = 0; i < grade.size(); i++) {
		String adder = (String)grade.get(i);
		copyGrades.add(adder);
	}
	return copyGrades;
}// end of copyGradesToString method

/**
 * This is the method that prints the transcript to the given file (i.e. outputFile attribute)
 * @param students is a array list of students whose transcripts we want
 */
public void printTranscript(ArrayList<Student> students) {	
	try {
		File output = new File(outputFile);
		PrintWriter outs = new PrintWriter(output);
		for (Student studentname : students) {
	        outs.println(studentname);
		}
		outs.close();
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}	
}// end of printTranscript method

public static void main(String[] args) {
	System.out.println("Enter the name of the input file (with the extension included):");
	String inputname = input.nextLine();
	Transcript transcript = new Transcript(inputname, "outputTranscript.txt");
	transcript.printTranscript(transcript.buildStudentArray());
	System.out.println("File is processed. Check the directory for the file named outputTranscript.txt ."
			+ "Thank you!");
}

} // end of Transcript

/**
 * This class generates a student object and the information of that student(i.e. courses taken, grades achieved, GPA etc)
 *
 */
class Student {
	
	private String studentID;
	private String name;
	private ArrayList<Course> courseTaken = new ArrayList<Course>();
	private ArrayList<Double> finalGrade = new ArrayList<Double>();
	
	/**
	 * Default constructor for this class.
	 */
	public Student() {
	}// end of this course
	
	/**
	 * @param studentID is the student id of student
	 * @param name is the name of student
	 * @param courseTaken is the array list of courses taken by this student
	 */
	public Student(String studentID, String name, ArrayList<Course> courseTaken) {
		courseTaken = new ArrayList<>();
		finalGrade = new ArrayList<>();
		this.studentID = studentID;
		this.name = name;
		this.courseTaken = courseTaken;
	}// end of this constructor
	
	/**
	 * @return the student id for this student.
	 */
	public String getStudentID() {
		return studentID;
	}// end of get getStudentID method
	
	/**
	 * @return the name of this student.
	 */
	public String getName() {
		return name;
	}// end of getName method
	
	/**
	 * This method sets the course you want to add to this student.
	 * @param other is the course you want to add to this student.
	 */
	public void addCourse(Course other) {
		courseTaken.add(other);
	}// end of addCourse method
	
	/**
	 * This method sets the id we want to set to this student
	 * @param studentID is the id we want to set to this student
	 */
	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}// end of setStudentID method
	
	/**
	 * @return the array list of courses taken by this student
	 */
	public ArrayList<Course> getCourseTaken() {
		return courseTaken;
	}// end of getCourseTaken method
	
	/**
	 * This method sets the array list of courses that we want to set for this student
	 * @param courseTaken is the array list of courses
	 */
	public void setCourseTaken(ArrayList<Course> courseTaken) {
		this.courseTaken = courseTaken;
	}// end of setCourseTaken method
	
	/**
	 * @return the array list of final grades
	 */
	public ArrayList<Double> getFinalGrade() {
		return finalGrade;
	}// end of getFinalGrade method
	
	/**
	 * This method sets the set of final grades that you want to set to this student.
	 * @param finalGrade is the set of final grades that you want to set to this student.
	 */
	public void setFinalGrade(ArrayList<Double> finalGrade) {
		this.finalGrade = finalGrade;
	}// end of setFinalGrade method
	
	/**
	 * This method sets the name of this student
	 * @param name is the name you want to set for this student
	 */
	public void setName(String name) {
		this.name = name;
	}// end of setName method
	
	/**
	 * This is a private helper method for addGrade method which
	 * sums up all the weights and check whether they are are equal to 100 or not.
	 * @param weights is the array list of weights of a course.
	 * @return true if the sum of the weights are equal to 100 or else return false.
	 */
	private boolean totalWeight(ArrayList<Integer> weights) {
		int total = 0;
		for(int i: weights) {
			total += i;
		}
		if (total == 100) {
			return true;
		} else {
			return false;
		}
	}// end of totalWeight method
	
	/**
	 * This is a private helper method for addGrade method which
	 * checks all grades of a course and verifies whether it exceeds 100 or not.
	 * @param grades is the array list of grades that needs to be checked.
	 * @return true if all the grades are 100 or lower or else returns false.
	 */
	private boolean checkAllGrades(ArrayList<Double> grades) {
		boolean result = true;
		for(double i: grades) {
			if(grades.get((int) i) <= 1) {
				result = result && true;
			} else {
				result = false;
			}
		}
		return result;
	}// end of checkAllGrades method
	
	/**
	 * This method gets an array list of the grades and their weights, computes the true value
	 * of the grade based on its weight and add it to finalGrade attribute. In case the sum of the weight was 
	 * not 100, or the sum of grade was greater 100, it throws InvalidTotalException.
	 * @param grades is the array list of grades
	 * @param weights is the array list of weights
	 */
	public void addGrade(ArrayList<Double> grades, ArrayList<Integer> weights) {
		double total = 0;
		try {
			if(totalWeight(weights)){
				for(int i = 0; i < grades.size(); i++) {
					total = total + (grades.get(i) * weights.get(i));
				}
				total = setOneDec(total);
			} else { 
				throw new InvalidTotalException("The total weight is not equal to 100");
			}
			if(!checkAllGrades(grades)) {
				throw new InvalidTotalException("One of the grade of the assessments exceeds 100");
			}
		} catch(InvalidTotalException e) {
			e.printStackTrace();
		}
		finalGrade.add(total);
	}// end of addGrade method
	
	/**
	 * This is private helper method to generate numbers in one decimal point. 
	 * @param score is the number we want in one decimal point.
	 * @return is the number in one decimal point.
	 */
	private double setOneDec(double score) {
        DecimalFormat df = new DecimalFormat("#.#");
        String scorestring = df.format(score);
        return Double.parseDouble(scorestring);
	}// end of setOneDec method
	
	/**
	 * It is the method that computes the GPA.
	 * @return the GPA of this student
	 */
	public double weightedGPA() {
		double total = 0; 
		double creditTotal =0;          
        for(int i =0; i< courseTaken.size(); i++)      {
                total = total + (courseTaken.get(i).getCredit() * getGradePoint(finalGrade.get(i)));
                creditTotal = creditTotal + courseTaken.get(i).getCredit();
        }               
    total= total/creditTotal;
	total = setOneDec(total);
    return total;
	}// end of weightedGPA method
	
	/**
	 * This is a private helper method for weightedGPA method that helps to calculate weighted GPA. 
	 * @param grade is the grade achieved by the student for this course.
	 * @return the grade point achieved for this course by the student.
	 */
	private int getGradePoint(double grade){
		int result =  0;
        if(grade > 89.99){
                result = 9;
        }else if(grade > 79.99){
                result = 8;
        }else if(grade > 74.99){
                result = 7;
        }else if(grade > 69.99){
                result = 6;
        }else if(grade > 64.99){
                result = 5;
        }else if(grade > 59.99){
                result = 4;
        }else if(grade > 54.99){
                result = 3;
        }else if(grade > 49.99){
                result = 2;
        }else if(grade >= 47){
                result = 1;
        }
        return result;
	}// end of getGradePoint method
	
	/**
	 *This is an overridden method of Object's method
	 *that returns the String representation of a student's information.
	 */
	@Override
    public String toString() {
            String student = "";
            String course = "--------------------";
            String gpa = "\n--------------------";
            student = student+name+"\t"+studentID+"\n";
            for(int i =0; i<courseTaken.size();i++)      {
                    course = course +"\n"+(courseTaken.get(i).getCode()+"\t" + finalGrade.get(i));
            }
            gpa = gpa +"\nGPA: "+weightedGPA();
            return student+course+gpa+"\n";
    }// end of toString
	
}// end of Student class

/**
 * This class generates a single course for a student.
 *
 */
class Course {
	
	private String code;
	private ArrayList<Assessment> assignment = new ArrayList<Assessment>();
	private double credit;
	
	/**
	 * Default constructor of this class.
	 */
	public Course() {
	}// end of this constructor
	
	/**
	 * This is a constructor of Course.
	 * @param code is the code of the course
	 * @param assignment is the ArrayList of assignments for this course
	 * @param credit is the credit of this course
	 */
	public Course(String code, ArrayList<Assessment> assignment, double credit) {
		this.code = code;
		this.assignment = assignment;
		this.credit = credit;
	}// end of this constructor
	
	/**
	 * This is a copy constructor of Class Course.
	 * @param other is the course you wannt to copy.
	 */
	public Course(Course other) {
		this(other.code, other.assignment, other.credit);
	}// end of copy constructor
	
	/**
	 * @return the ArrayList of assignments for this course. 
	 */
	public ArrayList<Assessment> getAssignment() {
		return assignment;
	}// end of getAssignment
	
	/**
	 * This method sets an ArrayList of assignments that you want to set to this course.
	 * @param assignment is an ArrayList of assignments that you want to set to this course.
	 */
	public void setAssignment(ArrayList<Assessment> assignment) {
		this.assignment = assignment;
	}// end of setAssignment
	
	/**
	 * @return the credit of this course.
	 */
	public double getCredit() {
		return credit;
	}// end of getCredit method
	
	/**
	 * This method sets the credit that you want to set to this course.
	 * @param credit is the credit that you want to set to this course.
	 */
	public void setCredit(double credit) {
		this.credit = credit;
	}// end of setCredit
	
	/**
	 * This method sets the code that you want to set to this course.
	 * @param code is the code that you want to set to this course.
	 */
	public void setCode(String code) {
		this.code = code;
	}// end of setCode

	/**
	 * @return the course code for this course.
	 */
	public String getCode() {
		return code;
	}// end of getCode
	
	/**
	 *This is an overridden method for Object’s equals() method 
	 *that returns true, if all the instance variables of two objects have the same value.
	 */
	public boolean equals(Object obj) {
		Course other = (Course) obj;
		boolean result;
		if(obj == null) {
			result = false;
		} else if(this == obj) {
			result = true;
		} else if (this.getClass() != obj.getClass()) {
			result = false;
		} else if(this.code.equals(other.code) && this.assignment.equals(other.assignment) && this.credit == other.credit) {
			result = true;
		} else {
			result = false;
		}
		return result;
		 
	}// end equals method
}// end of Course class

/**
 * This class generates a single assessment.
 */
class Assessment {
	private char type;
	private int weight;
	
	/**
	 * Private default constructor of Assessment.
	 */
	private Assessment() {
		super();
	}// end of this constructor
	
	/**
	 * This is a private constructor of Assessment class.
	 * @param type is the type that you want to set to this particular assessment.
	 * @param weight is the weight that you want to set to this particular assessment.
	 */
	private Assessment(char type, int weight) {
		super();
		this.type = type;
		this.weight = weight;
	}// end of this constructor
	
	/**
	 * @return the type for this assessment.
	 */
	public char getType() {
		return type;
	}// end of getType method
	
	/**
	 * This is a method that sets the type of type for this assessment.
	 * @param type is the type that you want to set to this particular assessment.
	 */
	public void setType(char type) {
		this.type = type;
	}// end of setType method
	
	/**
	 * @return the weight for this assessment.
	 */
	public int getWeight() {
		return weight;
	}// end of getWeight method
	
	/**
	 * This is a method that sets the value of weight for this assessment.
	 * @param weight is the weight that you want to set to this particular assessment.
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}// end of setWeight method
	
	/**
	 * This is a public static factory method for class Assessment.
	 * @param type is the type of assessment. P for practical and E for exams.
	 * @param weight is the weight of the type of assessment on total marks of the course.
	 * @return an instance of class Assessment if type is P or E or returns null.
	 */
	public static Assessment getInstance(char type, int weight) {
		if(type == 'P' || type == 'E') {
			Assessment instance = new Assessment(type, weight);
			return instance;
		} else {
			return null;
		}	
	}// end of getInstance method
	
	/**
	 *This is an overridden method for Object’s equals() method 
	 *that returns true, if all the instance variables of two objects have the same value.
	 */
	public boolean equals(Object obj) {
		Assessment other = (Assessment) obj;
		boolean result;
		if(obj == null) {
			result = false;
		} else if(this == obj) {
			result = true;
		} else if (this.getClass() != obj.getClass()) {
			result = false;
		} else if (this.type == other.type && this.weight == other.weight) {
			result = true;
		} else {
			result = false;
		}
		return result;
		
	}// end of equals method
	
}// end of Assessment class

/**
 * This is an exception class which generates InvalidTotalException when
 * the total of grades and weights do not meets the expectation.
 *
 */
class InvalidTotalException extends Exception {
	/**
	 * This is constructor for this exception class. It calls the constructor of
	 * Exception class (super constructor) to generate exception.
	 * @param message is the error message that the compiler wants to generate.
	 */
	public InvalidTotalException(String message) {
		super(message);

	}
} // end of InvalidTotalException